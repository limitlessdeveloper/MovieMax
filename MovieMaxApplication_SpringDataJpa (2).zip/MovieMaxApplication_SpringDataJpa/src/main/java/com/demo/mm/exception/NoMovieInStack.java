package com.demo.mm.exception;

public class NoMovieInStack extends MovieMaxException{

	/*
	 * This exception is thrown from MovieRepository class with exception
	 * MovieService.NO_MOVIE_IN_STACK as the no movie is currently screening. 
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoMovieInStack(String message) {
		super(message);
	}

	
}
