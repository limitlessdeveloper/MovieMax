package com.demo.mm.exception;

public class InvalidUserNameException extends MovieMaxException{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidUserNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
