package com.demo.mm.exception;

public class MovieNotFoundException extends MovieMaxException{

	
	/*
	 * This exception is thrown from MovieRepository class with exception
	 * MovieService.MOVIE_NOT_FOUND as the given movie is not currently screening. 
	 */
	
	private static final long serialVersionUID = 1L;

	public MovieNotFoundException(String message) {
		super(message);
	}

}
