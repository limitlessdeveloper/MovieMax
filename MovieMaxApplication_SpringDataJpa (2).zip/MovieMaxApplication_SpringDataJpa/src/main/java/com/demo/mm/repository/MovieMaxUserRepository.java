package com.demo.mm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.mm.entity.UserEntity;

public interface MovieMaxUserRepository extends JpaRepository<UserEntity, String>{

}
