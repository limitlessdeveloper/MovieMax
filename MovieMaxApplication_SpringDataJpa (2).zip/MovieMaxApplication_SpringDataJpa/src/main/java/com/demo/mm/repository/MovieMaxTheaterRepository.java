package com.demo.mm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.mm.entity.TheaterEntity;

public interface MovieMaxTheaterRepository extends JpaRepository<TheaterEntity, String> {

	List<TheaterEntity> findAll();
}
