package com.demo.mm.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="theatermovieshow")
public class TheaterMovieShowEntity {

	@Id
	private String showid;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "theaterid", unique = true)
	private TheaterEntity theater;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "movieid", unique = true)
	private MovieEntity movie;
	private String showtime;
	private Date startdate;
	private Date enddate;
	private double ticketrate;
	
	
	public String getShowid() {
		return showid;
	}
	public void setShowid(String showid) {
		this.showid = showid;
	}
	public TheaterEntity getTheater() {
		return theater;
	}
	public void setTheater(TheaterEntity theater) {
		this.theater = theater;
	}
	public MovieEntity getMovie() {
		return movie;
	}
	public void setMovie(MovieEntity movie) {
		this.movie = movie;
	}
	public String getShowtime() {
		return showtime;
	}
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	public double getTicketrate() {
		return ticketrate;
	}
	public void setTicketrate(double ticketrate) {
		this.ticketrate = ticketrate;
	}
}
