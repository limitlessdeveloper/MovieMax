package com.demo.mm.exception;

public class InvalidPhoneNoException extends MovieMaxException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPhoneNoException(String message) {
		super(message);
		
	}

}
