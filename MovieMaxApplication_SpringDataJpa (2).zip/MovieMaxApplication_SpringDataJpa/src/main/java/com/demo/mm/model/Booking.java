package com.demo.mm.model;

import java.util.Date;

public class Booking {

	private int bookingid;
	private User userid;
	private TheaterMovieShow showid;
	private int noofseat;
	private double amountpaid;
	private Date showdate;
	private Date bookingdate;
	public int getBookingid() {
		return bookingid;
	}
	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}
	public User getUserid() {
		return userid;
	}
	public void setUserid(User userid) {
		this.userid = userid;
	}
	public TheaterMovieShow getShowid() {
		return showid;
	}
	public void setShowid(TheaterMovieShow showid) {
		this.showid = showid;
	}
	public int getNoofseat() {
		return noofseat;
	}
	public void setNoofseat(int noofseat) {
		this.noofseat = noofseat;
	}
	public double getAmountpaid() {
		return amountpaid;
	}
	public void setAmountpaid(double amountpaid) {
		this.amountpaid = amountpaid;
	}
	public Date getShowdate() {
		return showdate;
	}
	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}
	public Date getBookingdate() {
		return bookingdate;
	}
	public void setBookingdate(Date bookingdate) {
		this.bookingdate = bookingdate;
	}
	
	
}
