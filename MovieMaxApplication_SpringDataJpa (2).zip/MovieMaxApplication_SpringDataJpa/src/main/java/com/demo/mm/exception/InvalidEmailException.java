package com.demo.mm.exception;

public class InvalidEmailException extends MovieMaxException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidEmailException(String message) {
		super(message);
		
	}

}
