package com.demo.mm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.mm.entity.MovieEntity;

public interface MovieMaxMoviesRepository extends JpaRepository<MovieEntity, String>{

	List<MovieEntity> findAll();

}
