package com.demo.mm.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.mm.entity.MovieEntity;
import com.demo.mm.entity.TheaterEntity;
import com.demo.mm.entity.UserEntity;
import com.demo.mm.exception.InvalidEmailException;
import com.demo.mm.exception.InvalidPasswordException;
import com.demo.mm.exception.InvalidPhoneNoException;
import com.demo.mm.exception.InvalidUserIdException;
import com.demo.mm.exception.InvalidUserNameException;
import com.demo.mm.exception.MovieMaxException;
import com.demo.mm.exception.NoMovieInStack;
import com.demo.mm.exception.NoTheaterInStack;
import com.demo.mm.exception.UserIdAlreadyPresentException;
import com.demo.mm.model.User;
import com.demo.mm.repository.MovieMaxMoviesRepository;
import com.demo.mm.repository.MovieMaxTheaterRepository;
import com.demo.mm.repository.MovieMaxUserRepository;

@Service
public class MovieService {

	@Autowired
	MovieMaxUserRepository movieMaxUserRepository;
	@Autowired
	MovieMaxMoviesRepository movieMaxMoviesRepository;
	@Autowired
	MovieMaxTheaterRepository movieMaxTheaterRepository;
	
	String regex = "^[a-zA-Z0-9]{4,15}$";
	
	public String registerUser(User user)throws MovieMaxException{
		
		validateUser(user);
		boolean b = movieMaxUserRepository.existsById(user.getUserId());
		if(b) {
			throw new UserIdAlreadyPresentException("MovieService.USERID_PRESENT");
		}
		else{
			UserEntity userEntity = new UserEntity();
			userEntity.setUserid(user.getUserId());
			userEntity.setPassword(user.getPassword());
			userEntity.setUsername(user.getUserName());
			userEntity.setEmailid(user.getEmail());
			userEntity.setPhone(user.getPhone());
			movieMaxUserRepository.saveAndFlush(userEntity);
			return "MovieService.REGISTRATION_SUCCESS";
		}
	}
		
	public List<MovieEntity> getAllMovies()throws MovieMaxException{

			List<MovieEntity> movies = movieMaxMoviesRepository.findAll();
			if(movies == null) {
				throw new NoMovieInStack("MovieService.NO_MOVIE_IS_SCREENING");
			}
			return movies;			
		}
	
	public List<TheaterEntity> getAllTheater()throws MovieMaxException{

		List<TheaterEntity> theaters = movieMaxTheaterRepository.findAll();
		if(theaters == null) {
			throw new NoTheaterInStack("MovieService.NO_THEATER_AVAILABLE");
		}
		return theaters;			
	}
	
	
	public void validateUser(User user) throws MovieMaxException{
		
		if (!isValidUserId(user.getUserId()))
		 throw new InvalidUserIdException("MovieService.INVALID_USER_ID");
		if (!isValidPassword(user.getPassword()))
			throw new InvalidPasswordException("MovieService.INVALID_PASSWORD");
		if (!isValidUserName(user.getUserName()))
			throw new InvalidUserNameException("MovieService.INVALID_USER_NAME");
		if (!isValidEmail(user.getEmail()))
			throw new InvalidEmailException("MovieService.INVALID_EMAIL");
		if (!isValidPhone(user.getPhone()))
			throw new InvalidPhoneNoException("RegistrationService.INVALID_PHONE_NUMBER");
	}

	private boolean isValidPhone(long phone) {
		boolean b = false;
		String regex1 = "[0-9]{10}";
		String phone_nm = Long.toString(phone);
		Pattern p = Pattern.compile(regex1);
		Matcher m = p.matcher(phone_nm);
		if(m.matches())
			b = true;
		return b;
	}

	private boolean isValidEmail(String email) {
		boolean b = false;
		String regex2 = "^[a-zA-Z0-9+_.-]+@(.+)$";
		Pattern p = Pattern.compile(regex2);
		Matcher m = p.matcher(email);
		if(m.matches()) {
			b = true;
		}
		return b;
	}

	private boolean isValidUserName(String userName) {
		boolean b = false;
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(userName);
		if(m.matches()) {
			b = true;
		}
		return b;
	}

	private boolean isValidPassword(String password) {
		boolean b = false;
		String regex2 = "^[a-zA-Z0-9]{8,15}$";
		Pattern p = Pattern.compile(regex2);
		Matcher m = p.matcher(password);
		if(m.matches()) {
			b = true;
		}
		return b;
	}

	private boolean isValidUserId(String userId) {
		boolean b = false;
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(userId);
		if(m.matches()) {
			b = true;
		}
		return b;
	}
	
}
