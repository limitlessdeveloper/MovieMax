package com.demo.mm.exception;

public class InvalidPasswordException extends MovieMaxException{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;

	public InvalidPasswordException(String message) {
		super(message);
	}

	
}
