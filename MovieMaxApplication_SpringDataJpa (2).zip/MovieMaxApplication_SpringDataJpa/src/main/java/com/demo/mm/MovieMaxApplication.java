package com.demo.mm;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.demo.mm.entity.MovieEntity;
import com.demo.mm.entity.TheaterEntity;
import com.demo.mm.exception.MovieMaxException;
import com.demo.mm.model.User;
import com.demo.mm.service.MovieService;

@SpringBootApplication
@PropertySource(value = { "classpath:configuration.properties" })
public class MovieMaxApplication implements CommandLineRunner{

	@Autowired
	private Environment environment;
	@Autowired
	ApplicationContext context;
	
	public static void main(String[] args) {
		SpringApplication.run(MovieMaxApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		try {
			User user = new User();
			user.setUserId("pranjal12");
			user.setUserName("pranjal");
			user.setPassword("Pranjal123456");
			user.setEmail("pranjal09@gmail.com");
			user.setPhone(9789456124L);
			
			
			MovieService movieService = (MovieService)context.getBean("movieService");
			
			String registrationMessage = movieService.registerUser(user);			
			System.out.println(environment.getProperty(registrationMessage));
			List<MovieEntity> movies = movieService.getAllMovies();
			System.out.println("Select a theater");
			List<TheaterEntity> theaters = movieService.getAllTheater();
			for(int i =0; i<theaters.size();i++) {
				System.out.println(theaters.get(i).getTheatername());
			}
			Scanner s = new Scanner(System.in);
			String theaterName = s.nextLine();
			System.out.println("Select a Movie");
			for(int i =0; i<movies.size();i++) {
				System.out.println(movies.get(i).getMoviename());
			}
			String movieName = s.next();  
			for(int i =0; i<movies.size();i++) {
				if(movieName.equalsIgnoreCase(movies.get(i).getMoviename())) {
					System.out.println("Hi "+user.getUserName());
					System.out.println("Movie is successfully booked, blow are the details");
					System.out.println();
					System.out.println("Movie Name:" + movies.get(i).getMoviename() +" in "+theaterName);
				}
			}
			
		}
		catch (MovieMaxException e) {
			System.out.println(environment.getProperty(e.getMessage()));
		}		
	}

}
