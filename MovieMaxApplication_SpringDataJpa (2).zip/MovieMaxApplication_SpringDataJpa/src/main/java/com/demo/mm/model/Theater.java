package com.demo.mm.model;

public class Theater {

	private String theaterid;
	private String theatername;
	private int seatsavailable;
	private String city;
	
	
	public String getTheaterId() {
		return theaterid;
	}
	public void setTheaterId(String theaterId) {
		this.theaterid = theaterId;
	}
	public String getTheaterName() {
		return theatername;
	}
	public void setTheaterName(String theaterName) {
		this.theatername = theaterName;
	}
	public int getSeatsAvailable() {
		return seatsavailable;
	}
	public void setSeatsAvailable(int seatsAvailable) {
		this.seatsavailable = seatsAvailable;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
