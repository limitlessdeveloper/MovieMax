package com.demo.mm.model;

public class Movie {

	private String movieid;
	private String moviename;
	private String language;
	private String category;
	private boolean islive;
	
	public String getMovieId() {
		return movieid;
	}
	public void setMovieId(String movieId) {
		this.movieid = movieId;
	}
	public String getMovieName() {
		return moviename;
	}
	public void setMovieName(String movieName) {
		this.moviename = movieName;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public boolean isLive() {
		return islive;
	}
	public void setLive(boolean isLive) {
		this.islive = isLive;
	}
	
}
