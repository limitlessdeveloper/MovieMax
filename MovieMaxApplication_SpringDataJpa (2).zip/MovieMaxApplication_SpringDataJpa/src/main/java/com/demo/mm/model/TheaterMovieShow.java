package com.demo.mm.model;

import java.util.Date;

public class TheaterMovieShow {

  private String showid;
  private Theater theater;
  private Movie movie;
  private String showtime;
  private Date startdate;
  private Date enddate;
  private double ticketrate;
  
	public String getShowid() {
		return showid;
	}
	public void setShowid(String showid) {
		this.showid = showid;
	}
	public Theater getTheater() {
		return theater;
	}
	public void setTheater(Theater theater) {
		this.theater = theater;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	public String getShowtime() {
		return showtime;
	}
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	public double getTicketrate() {
		return ticketrate;
	}
	public void setTicketrate(double ticketrate) {
		this.ticketrate = ticketrate;
	}
}
