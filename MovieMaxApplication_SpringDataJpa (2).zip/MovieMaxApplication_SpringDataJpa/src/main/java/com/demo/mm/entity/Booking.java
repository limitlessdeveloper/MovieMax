package com.demo.mm.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "booking")
public class Booking {

	@Id
	private int bookingid;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="userid", unique=true)
	private UserEntity user;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="showid", unique=true)
	private TheaterMovieShowEntity show;
	private int noofseat;
	private double amountpaid;
	private Date showdate;
	private Date bookingdate;
	
	public int getBookingid() {
		return bookingid;
	}
	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}
	public UserEntity getUser() {
		return user;
	}
	public void setUser(UserEntity user) {
		this.user = user;
	}
	public TheaterMovieShowEntity getShow() {
		return show;
	}
	public void setShow(TheaterMovieShowEntity show) {
		this.show = show;
	}
	public int getNoofseat() {
		return noofseat;
	}
	public void setNoofseat(int noofseat) {
		this.noofseat = noofseat;
	}
	public double getAmountpaid() {
		return amountpaid;
	}
	public void setAmountpaid(double amountpaid) {
		this.amountpaid = amountpaid;
	}
	public Date getShowdate() {
		return showdate;
	}
	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}
	public Date getBookingdate() {
		return bookingdate;
	}
	public void setBookingdate(Date bookingdate) {
		this.bookingdate = bookingdate;
	}
	
	
}
