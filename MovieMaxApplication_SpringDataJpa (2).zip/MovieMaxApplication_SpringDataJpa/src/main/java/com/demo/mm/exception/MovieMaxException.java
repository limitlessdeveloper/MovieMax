package com.demo.mm.exception;

public class MovieMaxException extends Exception {

	
	
	private static final long serialVersionUID = 1L;

	/*
	 * This exception class is inherited by all the User defined Exception classes
	 * 
	 */
	
	public MovieMaxException(String message) {
		super(message);
	}

}
