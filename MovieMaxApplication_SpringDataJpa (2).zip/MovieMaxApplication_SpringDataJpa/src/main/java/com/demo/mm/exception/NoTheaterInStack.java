package com.demo.mm.exception;

public class NoTheaterInStack extends MovieMaxException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoTheaterInStack(String message) {
		super(message);
		
	}

}
