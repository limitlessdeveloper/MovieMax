package com.demo.mm.exception;

public class InvalidUserIdException extends MovieMaxException{

	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;

	public InvalidUserIdException(String message) {
		super(message);
	}

}
